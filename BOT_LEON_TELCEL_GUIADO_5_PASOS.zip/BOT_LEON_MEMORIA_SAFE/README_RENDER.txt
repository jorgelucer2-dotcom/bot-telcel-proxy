BOT LEÓN - MEMORIA SAFE V1

Cambios para Render:
- Limita Chromium LOCAL simultáneo a 1 por defecto en Render.
- Las operaciones adicionales esperan en cola en vez de abrir más Chromium y agotar RAM.
- Los navegadores remotos por CDP/BrightData no consumen un slot local.
- Registra RSS/HEAP/EXT cada 60 segundos.
- Omite el smoke test de Chromium en Render para ahorrar memoria al arrancar.
- Refuerza liberación de slots cuando se cierran Telcel, BAIT, Telcel Tienda y Netflix.
- Conserva la implementación de hasta 3 tarjetas en sesión y reutilización tras éxito.

Variables opcionales en Render:
MAX_BROWSER_CONCURRENCY=1   (recomendado para empezar)
MEMORY_SOFT_LIMIT_MB=0      (0 = desactivado; usa un valor solo si conoces el límite real de tu instancia)
SKIP_PLAYWRIGHT_SMOKE_TEST=true

En logs debes ver:
🧠 MEMORIA SAFE V1 | Chromium local máx=1 | límite suave=OFFMB
[MEMORIA] RSS=...MB HEAP=...MB EXT=...MB | ChromiumLocal=... | cola=...

Si después de varias pruebas la RAM queda estable y tu plan tiene margen, prueba MAX_BROWSER_CONCURRENCY=2.
